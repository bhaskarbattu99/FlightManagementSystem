package com.cg.flightmgmt.exception;

public class AirportNotFoundException extends Exception{
	public AirportNotFoundException(String str) {
		super(str);
	}
}
