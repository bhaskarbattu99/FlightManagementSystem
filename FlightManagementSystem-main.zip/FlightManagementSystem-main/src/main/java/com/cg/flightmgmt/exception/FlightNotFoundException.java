package com.cg.flightmgmt.exception;

public class FlightNotFoundException extends Exception{
	public FlightNotFoundException(String str) {
		super(str);
	}
}
