package com.cg.flightmgmt.service;

import com.cg.flightmgmt.dto.Schedule;

public interface ScheduleService  {
	public Schedule createSchedule(Schedule schedule);
}