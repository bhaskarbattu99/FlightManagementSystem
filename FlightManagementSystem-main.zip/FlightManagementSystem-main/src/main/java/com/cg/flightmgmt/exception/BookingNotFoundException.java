package com.cg.flightmgmt.exception;

public class BookingNotFoundException extends Exception{
	public BookingNotFoundException(String str) {
		super(str);
	}
}
