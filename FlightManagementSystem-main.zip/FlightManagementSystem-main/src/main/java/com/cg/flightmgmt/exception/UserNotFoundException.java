package com.cg.flightmgmt.exception;

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String str) {
		super(str);
	}
}
